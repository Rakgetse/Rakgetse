<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "onlinerental";
?>